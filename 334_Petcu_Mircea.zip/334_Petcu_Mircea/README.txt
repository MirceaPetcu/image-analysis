Requirements:
opencv_python==4.8.1
numpy==1.24.3
Rulare:
Se ruleaza toate task-urile deodata in fisierul jupyter notebook toate_task_urile.ipynb. Se ruleaza toate celulele
de sus pana jos. Trebuie schimbat path-ul catre fisierele de input (variabila 'path' de pe linia 4 din celula de 
citire a inputului marcata corespunzator cu un markdown inaintea acesteia), iar variabila 'test' din aceeasi celula
trebuie lasata (sau setata daca nu este deja) la True. Timpul efectiv pentru rularea task-urilor din celula de rulat 
( marcata corespunzator cu un markdown inaintea acesteia) este de aproximativ 1 minut. Programul va creea in directorul
curent fisierele text cu solutiile pentru fiecare runda a fiecarui joc (Eg. runda 1 din jocul 1 va fi in fisierul 
1_01.txt). In fisierel text creeate vor exista, sub formatul regasit in directorul 'antrenare', solutiile pentru fiecare
task.